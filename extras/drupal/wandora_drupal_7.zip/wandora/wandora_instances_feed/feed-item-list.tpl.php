<?php
/**
 * @file feed-item-list.tpl.php
 * Display list view of the feed and it's items
 *
 * Variables available:
 * - $items: Simple array of strings to be displayed
 * - $title: The title of the feed.
 *
 * @see template_preprocess_feed_item_list()
 */

drupal_set_title($title);
?>
<div class="item-list"><?php print theme('item_list', array('items' => $items));?></div>
