<?php
/**
 * @file feed-item-list.tpl.php
 * Display list view of the feed and it's items
 *
 * Variables available:
 * - $title: The title of the item.
 * - $description: The description of the item.
 * - $links: Array of links 
 * @see template_preprocess_feed_item_list()
 */

drupal_set_title($title);
?>
<div class="description"><?php print html_entity_decode($description);?></div>
<div><?php print theme('links', $links);?></div>