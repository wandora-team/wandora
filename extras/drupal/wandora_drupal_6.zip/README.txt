
============================================================================
Table of Contents
============================================================================

1. General requirements and installation
2. Wandora module
3. Instances Feed View module
4. Topic Feed View module
5. SOAP reader module


============================================================================
1. General requirements and installation
============================================================================

General requirements
------------
This module requires Drupal 6.0 or a later version, can also work on previous
versions(not tested).

Some of the submodules require that a Wandora application HTTP server running
and configured. You can download one from here: http://www.wandora.org.

Some additional requirements can be required on different submodules.


Installation
------------

Installation procedure is very simple:

1) Copy/upload the wandora folder to the sites/all/modules directory 
   of your Drupal installation.
2) Enable the Wandora module and any of it's submodules you wish to use
   in Drupal (Administer -> modules).
3) Depending on what Wandora's submodules you have selected, each of them
   may require additional configuration. See Configuration section of each
   submodule you have enabled.
   
   
For more comprehensive documentation at
http://www.wandora.org/wandora/wiki/index.php?title=Wandora%27s_Drupal_Extras


============================================================================
2. Wandora module
============================================================================

Description
-----------
Wandora module handles the centralizing of settings for each it's submodules.
The module itself doesn't do much, but is mandatory if any of it's submodules
is enabled.


============================================================================
3. Instances Feed View module
============================================================================

Description
-----------

Instances Feed View is a module that read an rss feed provided by
Wandora and builds a small navigatable page out of it.


Configuration
-------------

Wandora Instances Feed View can be configured at:
  
  Administer -> Wandora -> Instances Feed View - Feed settings:
  
  - Path to feed
    The absolute or relative path to the feed.
  
  
============================================================================
4. Topic Feed View module
============================================================================

Description
-----------

Topic Feed View is a module that read an atom feed provided by
Wandora and builds a navigatable page out of it.


Configuration
-------------

Wandora Topic Feed View can be configured at:

  Administer -> Wandora -> Topic Feed View - Feed settings:
  
  - Path to feed
    The absolute or relative path to the feed.

Customization
-------------

* To modify the color of the generated tables:
  Open wandora/wandora_topic_feed/wandora_topic_feed.css file and modify the
  background-color and/or border parameters in these classes: .subtitle,
  .type and .cell.
  

============================================================================
5. SOAP reader module
============================================================================

Description
-----------

SOAP reader uses soap_php extension to read topics from Wandora application
and displays html presentation from the currently open topic.


Configuration
-------------

Wandora SOAP reader can be configured at:
  Administer -> Wandora -> SOAP reader - settings
  
	- Path to soap client:
      The absolute or relative path to the Wandora SOAP service.

	- Default subject identifier:
	  Subject identifier for the default topic.
	  
Customization
-------------

* To modify the color of the generated tables:
  Open wandora/wandora_soap/wandora_soap.css file and modify the
  background-color and/or border parameters in these classes: .subtitle,
  .type and .cell.
  
============================================================================
Author
============================================================================

 * Elias Tertsunen <elias@gripstudios.com>
